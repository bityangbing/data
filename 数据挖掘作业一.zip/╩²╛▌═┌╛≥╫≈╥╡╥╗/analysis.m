clear all;
clear all;

afid=fopen('analysis.txt'); 
txt=textscan(afid,'%[^\n\r]'); 
fclose(afid);
data = txt{1};
S = regexp(data, '\s+', 'split');

% ��cell�е��ַ���ת��������
for ai = 1 : 1 : 200
    for aj = 4 : 1 : 18
        S{ai}{aj} = str2num(S{ai}{aj});
    end
end

% ��ȡ���е�ǰ�����ַ���������D1��
D1 = cell(200,3);
for ai = 1 : 1 : 200
    for aj = 1 : 1 :3
        D1{ai,aj} = S{ai}{aj};
    end
end

% ��ǰ����Ƶ��
% fre_season = tabulate(D1(:,1));
% fre_size = tabulate(D1(:,2));
% fre_v = tabulate(D1(:,3));

% ��ȡ��������,������D2��
D2 = zeros(200,15);
for ai = 1 : 1 : 200
    for aj = 4 : 1 :18
        if(isempty(S{ai}{aj}) == 0)
            D2(ai,aj - 3) = S{ai}{aj};  
        else
            D2(ai,aj - 3) = nan;
        end
    end
end

%% �����ֵ����Сֵ��ƽ��ֵ����λ�������ķ�λ�������ķ�λ����ȱʡֵ����
% [max1, min1, mean1, median1, quar_up1, quar_down1, def1] = analynum(D2(:,1));
% [max2, min2, mean2, median2, quar_up2, quar_down2, def2] = analynum(D2(:,2));
% [max3, min3, mean3, median3, quar_up3, quar_down3, def3] = analynum(D2(:,3));
% [max4, min4, mean4, median4, quar_up4, quar_down4, def4] = analynum(D2(:,4));
% [max5, min5, mean5, median5, quar_up5, quar_down5, def5] = analynum(D2(:,5));
% [max6, min6, mean6, median6, quar_up6, quar_down6, def6] = analynum(D2(:,6));
% [max7, min7, mean7, median7, quar_up7, quar_down7, def7] = analynum(D2(:,7));
% [max8, min8, mean8, median8, quar_up8, quar_down8, def8] = analynum(D2(:,8));
% [max9, min9, mean9, median9, quar_up9, quar_down9, def9] = analynum(D2(:,9));
% [max10, min10, mean10, median10, quar_up10, quar_down10, def10] = analynum(D2(:,10));
% [max11, min11, mean11, median11, quar_up11, quar_down11, def11] = analynum(D2(:,11));
% [max12, min12, mean12, median12, quar_up12, quar_down12, def12] = analynum(D2(:,12));
% [max13, min13, mean13, median13, quar_up13, quar_down13, def13] = analynum(D2(:,13));
% [max14, min14, mean14, median14, quar_up14, quar_down14, def14] = analynum(D2(:,14));
% [max15, min15, mean15, median15, quar_up15, quar_down15, def15] = analynum(D2(:,15));

%% ����ֱ��ͼ��QQͼ����ͼ
% [a,b]=hist(D2(:,1),60);
% figure,bar(b,a/sum(a));
% figure,qqplot(D2(:,1));
% figure,boxplot([D2(:,1)]);


%% ȱʧ�޳�
% Ѱ��ȱʧֵ
% k = 1;
% for i=1:1:200
%     for j=1:1:15
%         if(isnan(D2(i,j)))
%             D2(i,:) = nan;
%             flag(k) = i;
%             k = k + 1;
%             break;
%         end
%     end
% end
% 
% D2(any(isnan(D2), 2),:) = [];
% D1(flag,:) = [];
% 
% savetxt(D1,D2,'1.txt');
 
%% ��Ƶ�

% D3 = D2; % �����ݼ�ΪD3
% for i=1:1:15
%     temp = D2(:,i);
%     fre_data = tabulate(D2(:,i));
%     [maxfre,index] = max(fre_data(:,2));
%     maxfre_data = fre_data(index,1);
%     temp(find(isnan(temp)==1)) = maxfre_data;
%     D3(:,i) = temp;
% end
% 
% savetxt(D1,D3,'2.txt');
%% ������
% for i = 1 : 1 : 15
%     for j = 1 : 1 : 15 
%         temp1 = D2(:,i);
%         temp2 = D2(:,j);
%         temp3 = temp1;
%         temp1(find(isnan(temp2)==1)) = nan;
%         temp2(find(isnan(temp3)==1)) = nan;
%         temp1 = temp1(~isnan(temp1));
%         temp2 = temp2(~isnan(temp2));
%         corr_temp = corrcoef(temp1,temp2);
%         corr(i, j) = corr_temp(1,2);
%     end
% end
% 
% x = D2(:, 6);
% y = D2(:, 7);
% x_temp = x;
% x(find(isnan(y)==1)) = nan;
% y(find(isnan(x_temp)==1)) = nan;
% x = x(~isnan(x));
% y = y(~isnan(y));
% p = polyfit(x, y, 1);
% p2 = polyfit(y, x, 1);
% % y = 1.29*x + 42.9
% % x = 0.65*y - 15.6
% for i=1:1:200
%     if(isnan(D2(i,7)) && (~isnan(D2(i,6))))
%         D2(i,7) = 1.29 * D2(i,6) + 42.9;
%     end
% end
% for i=1:1:200
%     if(isnan(D2(i,6)) && (~isnan(D2(i,7))))
%         D2(i,6) = 0.65 * D2(i,7) - 15.6;
%     end
% end
% savetxt(D1,D2,'3.txt');
%% ���ݶ���������

% Ѱ��ȱʧ������
% k = 1;
% for i=1:1:200
%     for j=1:1:15
%         if(isnan(D2(i,j)))
%             flag(k) = i;
%             k = k + 1;
%             break;
%         end
%     end
% end
% 
% [m,n] = size(flag);
% D3 = D2;
% for i=1:1:n
%     temp1 = D2(flag(i),:);
%     for j = 1 : 1 : 200 
%         temp2 = D2(j,:);
%         temp3 = temp1;
%         temp3(find(isnan(temp2)==1)) = nan;
%         temp2(find(isnan(temp1)==1)) = nan;
%         temp3 = temp3(~isnan(temp3));
%         temp2 = temp2(~isnan(temp2));
%         dis(j) = pdist2(temp2, temp3, 'Euclidean');
%     end
%     [dis_sort, index_dis] = sort(dis); % ��ŷʽ�����С��������õ����Ƶ�ˮ��
%     index_final = index_dis(6); % ��ǰ10��ˮ������λ������ˮ����Ϊ����ѡ��
%     
%     temp4 = D2(flag(i),:);     % �D2�еĿ�ȱ
%     temp5 = D2(index_final,:);
%     for j=1:1:15
%         if(isnan(temp4(j)))
%             temp4(j) = temp5(j);
%         end
%     end
%     D2(flag(i),:) = temp4;
% end
% savetxt(D1,D2,'4.txt');