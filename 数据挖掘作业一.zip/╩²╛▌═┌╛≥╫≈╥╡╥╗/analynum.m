function [maxnum, minnum, meannum, med, squrup, squrdown, def] = analynum(data)
maxnum = max(data);
minnum = min(data);
meannum = mean(data(~isnan(data)));
med = median(data(~isnan(data)));
squrup = prctile(data,25);
squrdown = prctile(data,75);
def = numel(find(isnan(data)));
end
