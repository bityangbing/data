function [] = savetxt(D1,D2,filename)
% �ϲ�D1��D2
[m,n] = size(D2);
D3 = cell(m,n+3);
for i=1:1:m
    for j=1:1:n+3
        if(j<=3)
            D3(i,j) = D1(i,j);
        else
            D3(i,j) = num2cell(D2(i,j-3));
        end
    end
end

% д��txt
[nrows,ncols]= size(D3);
 fid = fopen(filename, 'w');
 for row=1:nrows
     fprintf(fid, '%s %s %s %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f\r\n', D3{row,:});
 end
 fclose(fid);